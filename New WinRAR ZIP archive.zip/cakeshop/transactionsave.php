<?php
include "includes/connection.php";
 session_start();

          $del = $_POST['del'];             
            $query = 'SELECT current_date FROM tblusers';
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
               $date = $row['current_date'];
              }
        $tat=time();
if($_GET["action"]=='adds') {
            foreach($_SESSION['cart'] as $id => $value) {

            //Save Transaction
     $query2 = "INSERT INTO tbltransac(transac_code,date,user_id,product_code,qty,price,total)values('".$tat."','".$date."','".$_SESSION['userid']."','".$value['ids']."','".$value['quantity']."','".$value['price']."','".$value['quantity'] * $value['price']."')"; 
     mysqli_query($db,$query2)or die(mysqli_error($db));

     //Update Product
     $sql = "UPDATE tblproducts SET available = available - '".$value['quantity']."' WHERE product_code='".$value['ids']."'";
     mysqli_query($db,$sql)or die(mysqli_error($db));
  }
  //Save Transaction Detail 
  $query3 = "INSERT INTO tbltransacdetail(transac_code,date,customer_id,deliveryfee,totalprice,status,delivery_date)VALUES('".$tat."','".$date."','".$_SESSION['userid']."',150,'".$_SESSION['mm']."'+150,'Pending','".$del."')";
 mysqli_query($db,$query3)or die(mysqli_error($db)); 



#------------mailer-----------------------------------------------------
$query4 = 'SELECT email,concat(fname," ",lname)as name FROM tblusers WHERE user_id='.$_SESSION['userid'].'';
            $result2 = mysqli_query($db, $query4) or die(mysqli_error($db));
              while($row2 = mysqli_fetch_array($result2))
              {   
               $email = $row2['email'];
               $name = $row2['name'];
              }



 //$attachment = $_POST['pdf'];
 // Import PHPMailer classes into the global namespace
 // These must be at the top of your script, not inside a function
 
 
 // Load Composer's autoloader
 require 'phpmailer/PHPMailerAutoload.php';
 
 // Instantiation and passing `true` enables exceptions
 $mail = new PHPMailer(true);
 
 try {
     //Server settings
 
     $mail->isSMTP();                                            // Send using SMTP
     $mail->Host       = 'smtp.gmail.com';                       // Set the SMTP server to send through
     $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
     $mail->Username   = 'dpkcreed14@gmail.com';       // SMTP username
     $mail->Password   = 'creed@123';                         // SMTP password
     $mail->SMTPSecure = 'tls';         							// Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
     $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above
 
     //Recipients
     $mail->setFrom('dpkcreed14@gmail.com', 'My Cake Shop');
     $mail->addAddress($email);     // Add a recipient
     /*$mail->addReplyTo('info@example.com', 'Information');
     $mail->addCC('cc@example.com');
     $mail->addBCC('bcc@example.com');
 
     // Attachments
     $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
     $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
   */
     // Content
     $mail->isHTML(true);                                  // Set email format to HTML
     $mail->Subject = 'ORDER RECEIVED';
     $mail->Body    = "Hi {$name},<br>
 
 We have received your order.Please login to our webiste later to check confirmation on your order.
 Thank you for shopping with us. <br>
 
 <br>
 With Regards<br>
 My Cake Shop<br>";
     //$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
     //$mail->AddAttachment = $attachment;
     //$mail->addAttachment("student_certificates/{$name}.pdf");
     $mail->send();
     //echo '==> Email has been sent';
 } catch (Exception $e) {
     echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
 }

#------------End mailer-------------------------------------------------------------------


  
}
							
						 unset($_SESSION["cart"]);
             unset($_SESSION['mm']);	
				?>
    	
<script type="text/javascript">
			alert("Successfully added.");
			window.location = "index.php";
		</script>
