<?php include('includes/connection.php');?>  
<!--header area-->
<?php include 'includes/header.php'; ?>
<!--sidebar area-->
<?php include 'includes/sidebar.php'; ?>

<html>
<head>
<script>
function getParameterByName(name, url) {
        if (!url) url = window.location.href;
        name = name.replace(/[\[\]]/g, '\\$&');
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

    var cakename = getParameterByName('cake');
    <?php 
    $cake_name = "<script>document.write(cakename)</script>";
   
    ?>
    //document.write(cakename);
</script>
</head>
<body>
<?php 
$namecake = $_POST['cakedetails']; 
echo $namecake;
$query = "SELECT * FROM tblproducts where product_name= '$namecake'";
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<br> Cake Name: ". $row["product_name"]."<br>" . "Price: ". $row["selling_price"]. "<br>";
                }
            } else {
                echo "0 results";
            }
            #  while($row = mysqli_fetch_array($result))
            #  {   
              # $product_name = $row['product_name'];
              # $selling_price = $row['selling_price'];
            #}
            
?>


</body>
</html>


<?php include 'includes/footer.php'; ?>